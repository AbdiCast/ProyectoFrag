package org.example.repositorio;

import org.example.entities.Product;
import org.example.entities.SalesOrderHeader;
import org.example.util.ConexionBaseDatos;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class RepositorioImpl implements Repositorio<SalesOrderHeader>{
    private Connection getConnection() throws SQLException {
        return ConexionBaseDatos.getInstance();

    }
    @Override
    public List<SalesOrderHeader> listar() {
        List<SalesOrderHeader> ventas = new ArrayList<>();
        try(Statement stmt = getConnection().createStatement();
            ResultSet rs = stmt.executeQuery("select * from")) {

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return ventas;
    }

    @Override
    public SalesOrderHeader porId(Long id) {
        return null;
    }

    @Override
    public void guardar(SalesOrderHeader salesOrderHeader) {

    }
}
