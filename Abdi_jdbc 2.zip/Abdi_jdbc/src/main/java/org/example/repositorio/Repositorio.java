package org.example.repositorio;

import java.util.List;

public interface Repositorio<T> {
    List<T> listar(); //listar clientes
    T porId(Long id);
    void guardar(T t);


}
