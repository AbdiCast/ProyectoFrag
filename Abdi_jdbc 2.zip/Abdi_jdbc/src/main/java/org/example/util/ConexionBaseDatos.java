package org.example.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ConexionBaseDatos {
    private static String url = "jdbc:sqlserver://localhost/AdventureWorks2019?serverTimezone=UTC";
    private static String username = "sa";
    private static String password = "12341234";
    private static Connection connection;

    public static Connection getInstance() throws SQLException {
        if (connection == null){
            connection = DriverManager.getConnection(url, username, password);
        }
        return connection;
    }
}
