package org.example;


import org.example.util.ConexionBaseDatos;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.SQLException;
import java.sql.ResultSet;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        try(Connection conn = ConexionBaseDatos.getInstance();
            Statement stmt = conn.createStatement();
            ResultSet resultado = stmt.executeQuery("SELECT * from Person.Person")){
                while (resultado.next()) {
                    System.out.println(resultado.getString("LastName"));
                }

        } catch (SQLException e){
            e.printStackTrace();
        }
    }
}